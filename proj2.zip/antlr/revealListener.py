# Generated from java-escape by ANTLR 4.5
from antlr4 import *

# This class defines a complete listener for a parse tree produced by revealParser.
class revealListener(ParseTreeListener):

    # Enter a parse tree produced by revealParser#slideshow.
    def enterSlideshow(self, ctx):
        pass

    # Exit a parse tree produced by revealParser#slideshow.
    def exitSlideshow(self, ctx):
        pass


    # Enter a parse tree produced by revealParser#slide.
    def enterSlide(self, ctx):
        pass

    # Exit a parse tree produced by revealParser#slide.
    def exitSlide(self, ctx):
        pass


    # Enter a parse tree produced by revealParser#title.
    def enterTitle(self, ctx):
        pass

    # Exit a parse tree produced by revealParser#title.
    def exitTitle(self, ctx):
        pass


    # Enter a parse tree produced by revealParser#body.
    def enterBody(self, ctx):
        pass

    # Exit a parse tree produced by revealParser#body.
    def exitBody(self, ctx):
        pass


    # Enter a parse tree produced by revealParser#config.
    def enterConfig(self, ctx):
        pass

    # Exit a parse tree produced by revealParser#config.
    def exitConfig(self, ctx):
        pass


    # Enter a parse tree produced by revealParser#option.
    def enterOption(self, ctx):
        pass

    # Exit a parse tree produced by revealParser#option.
    def exitOption(self, ctx):
        pass


    # Enter a parse tree produced by revealParser#formatting.
    def enterFormatting(self, ctx):
        pass

    # Exit a parse tree produced by revealParser#formatting.
    def exitFormatting(self, ctx):
        pass


    # Enter a parse tree produced by revealParser#setting.
    def enterSetting(self, ctx):
        pass

    # Exit a parse tree produced by revealParser#setting.
    def exitSetting(self, ctx):
        pass


    # Enter a parse tree produced by revealParser#string.
    def enterString(self, ctx):
        pass

    # Exit a parse tree produced by revealParser#string.
    def exitString(self, ctx):
        pass


