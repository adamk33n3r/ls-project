# Generated from java-escape by ANTLR 4.5
from antlr4 import *
from io import StringIO


def serializedATN():
    with StringIO() as buf:
        buf.write("\3\u0430\ud6d1\u8206\uad2d\u4417\uaef1\u8d80\uaadd\2\22")
        buf.write("g\b\1\4\2\t\2\4\3\t\3\4\4\t\4\4\5\t\5\4\6\t\6\4\7\t\7")
        buf.write("\4\b\t\b\4\t\t\t\4\n\t\n\4\13\t\13\4\f\t\f\4\r\t\r\4\16")
        buf.write("\t\16\4\17\t\17\4\20\t\20\4\21\t\21\3\2\3\2\3\2\5\2\'")
        buf.write("\n\2\3\3\3\3\3\3\3\3\3\3\3\3\5\3/\n\3\3\4\3\4\3\5\3\5")
        buf.write("\3\6\3\6\3\7\3\7\3\b\6\b:\n\b\r\b\16\b;\3\t\3\t\3\t\3")
        buf.write("\t\6\tB\n\t\r\t\16\tC\3\n\3\n\6\nH\n\n\r\n\16\nI\3\13")
        buf.write("\3\13\3\f\6\fO\n\f\r\f\16\fP\3\r\3\r\3\16\3\16\3\16\3")
        buf.write("\16\3\16\3\16\5\16[\n\16\3\17\3\17\3\20\3\20\3\21\6\21")
        buf.write("b\n\21\r\21\16\21c\3\21\3\21\2\2\22\3\3\5\4\7\5\t\6\13")
        buf.write("\7\r\b\17\t\21\n\23\13\25\f\27\r\31\16\33\17\35\20\37")
        buf.write("\21!\22\3\2\6\4\2$$))\4\2C\\c|\f\2##%%\'\'*,..\60\61<")
        buf.write(">@A]`}\177\4\2\13\13\17\17s\2\3\3\2\2\2\2\5\3\2\2\2\2")
        buf.write("\7\3\2\2\2\2\t\3\2\2\2\2\13\3\2\2\2\2\r\3\2\2\2\2\17\3")
        buf.write("\2\2\2\2\21\3\2\2\2\2\23\3\2\2\2\2\25\3\2\2\2\2\27\3\2")
        buf.write("\2\2\2\31\3\2\2\2\2\33\3\2\2\2\2\35\3\2\2\2\2\37\3\2\2")
        buf.write("\2\2!\3\2\2\2\3&\3\2\2\2\5.\3\2\2\2\7\60\3\2\2\2\t\62")
        buf.write("\3\2\2\2\13\64\3\2\2\2\r\66\3\2\2\2\179\3\2\2\2\21=\3")
        buf.write("\2\2\2\23G\3\2\2\2\25K\3\2\2\2\27N\3\2\2\2\31R\3\2\2\2")
        buf.write("\33Z\3\2\2\2\35\\\3\2\2\2\37^\3\2\2\2!a\3\2\2\2#\'\7B")
        buf.write("\2\2$%\7B\2\2%\'\5\23\n\2&#\3\2\2\2&$\3\2\2\2\'\4\3\2")
        buf.write("\2\2()\7B\2\2)/\7B\2\2*+\7B\2\2+,\7B\2\2,-\3\2\2\2-/\5")
        buf.write("\23\n\2.(\3\2\2\2.*\3\2\2\2/\6\3\2\2\2\60\61\7&\2\2\61")
        buf.write("\b\3\2\2\2\62\63\7(\2\2\63\n\3\2\2\2\64\65\7/\2\2\65\f")
        buf.write("\3\2\2\2\66\67\t\2\2\2\67\16\3\2\2\28:\5\25\13\298\3\2")
        buf.write("\2\2:;\3\2\2\2;9\3\2\2\2;<\3\2\2\2<\20\3\2\2\2=A\5\17")
        buf.write("\b\2>?\5\13\6\2?@\5\17\b\2@B\3\2\2\2A>\3\2\2\2BC\3\2\2")
        buf.write("\2CA\3\2\2\2CD\3\2\2\2D\22\3\2\2\2EH\5\17\b\2FH\5\27\f")
        buf.write("\2GE\3\2\2\2GF\3\2\2\2HI\3\2\2\2IG\3\2\2\2IJ\3\2\2\2J")
        buf.write("\24\3\2\2\2KL\t\3\2\2L\26\3\2\2\2MO\5\31\r\2NM\3\2\2\2")
        buf.write("OP\3\2\2\2PN\3\2\2\2PQ\3\2\2\2Q\30\3\2\2\2RS\4\62;\2S")
        buf.write("\32\3\2\2\2T[\t\4\2\2U[\5\13\6\2V[\5\r\7\2W[\5\t\5\2X")
        buf.write("[\5\7\4\2Y[\5\3\2\2ZT\3\2\2\2ZU\3\2\2\2ZV\3\2\2\2ZW\3")
        buf.write("\2\2\2ZX\3\2\2\2ZY\3\2\2\2[\34\3\2\2\2\\]\7\f\2\2]\36")
        buf.write("\3\2\2\2^_\7\"\2\2_ \3\2\2\2`b\t\5\2\2a`\3\2\2\2bc\3\2")
        buf.write("\2\2ca\3\2\2\2cd\3\2\2\2de\3\2\2\2ef\b\21\2\2f\"\3\2\2")
        buf.write("\2\f\2&.;CGIPZc\3\b\2\2")
        return buf.getvalue()


class revealLexer(Lexer):

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]


    SLIDE = 1
    SLIDE2 = 2
    CONFIG = 3
    FORMAT = 4
    DASH = 5
    QUOTE = 6
    WORD = 7
    DASHWORD = 8
    ALPHANUM = 9
    LETTER = 10
    NUMBER = 11
    DIGIT = 12
    SYMBOL = 13
    NL = 14
    SPACE = 15
    WS = 16

    modeNames = [ u"DEFAULT_MODE" ]

    literalNames = [ u"<INVALID>",
            "'$'", "'&'", "'-'", "'\n'", "' '" ]

    symbolicNames = [ u"<INVALID>",
            "SLIDE", "SLIDE2", "CONFIG", "FORMAT", "DASH", "QUOTE", "WORD", 
            "DASHWORD", "ALPHANUM", "LETTER", "NUMBER", "DIGIT", "SYMBOL", 
            "NL", "SPACE", "WS" ]

    ruleNames = [ "SLIDE", "SLIDE2", "CONFIG", "FORMAT", "DASH", "QUOTE", 
                  "WORD", "DASHWORD", "ALPHANUM", "LETTER", "NUMBER", "DIGIT", 
                  "SYMBOL", "NL", "SPACE", "WS" ]

    grammarFileName = "reveal.g4"

    def __init__(self, input=None):
        super().__init__(input)
        self.checkVersion("4.5")
        self._interp = LexerATNSimulator(self, self.atn, self.decisionsToDFA, PredictionContextCache())
        self._actions = None
        self._predicates = None


